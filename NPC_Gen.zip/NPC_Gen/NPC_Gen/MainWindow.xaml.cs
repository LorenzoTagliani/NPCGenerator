﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NPC_Gen
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        Random rnd = new Random();
        int Frz_Mod = 0;
        int Dex_Mod = 0;
        int Con_Mod = 0;
        int Int_Mod = 0;
        int Wis_Mod = 0;
        int Cha_Mod = 0;
        int Frz;
        int Dex;
        int Con;
        int Int;
        int Wis;
        int Cha;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int[] mercante = new int[6];

            mercante[0] = Calcolo();
            mercante[1] = Calcolo();
            mercante[2] = Calcolo();
            mercante[3] = Calcolo();
            mercante[4] = Calcolo();
            mercante[5] = Calcolo();

            mercante = Riordinamento(mercante);

            Cha = mercante[5];
            Frz = mercante[4];
            Con = mercante[3];
            Dex = mercante[2];
            Int = mercante[1];
            Wis = mercante[0];

            Frz_res.Text = Frz.ToString();
            Dex_res.Text = Dex.ToString();
            Con_res.Text = Con.ToString();
            Int_res.Text = Int.ToString();
            Wis_res.Text = Wis.ToString();
            Cha_res.Text = Cha.ToString();

            Frz_Mod = Modifica(Frz);
            Dex_Mod = Modifica(Dex);
            Con_Mod = Modifica(Con);
            Int_Mod = Modifica(Int);
            Wis_Mod = Modifica(Wis);
            Cha_Mod = Modifica(Cha);

            Frz_mod.Text = Frz_Mod.ToString();
            Dex_mod.Text = Dex_Mod.ToString();
            Con_mod.Text = Con_Mod.ToString();
            Int_mod.Text = Int_Mod.ToString();
            Wis_mod.Text = Wis_Mod.ToString();
            Cha_mod.Text = Cha_Mod.ToString();
        }   //MERCANTE

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int[] guerrireo = new int[6];

            guerrireo[0] = Calcolo();
            guerrireo[1] = Calcolo();
            guerrireo[2] = Calcolo();
            guerrireo[3] = Calcolo();
            guerrireo[4] = Calcolo();
            guerrireo[5] = Calcolo();

            guerrireo = Riordinamento(guerrireo);

            Frz = guerrireo[5];
            Con = guerrireo[4];
            Dex = guerrireo[3];
            Cha = guerrireo[2];
            Int = guerrireo[1];
            Wis = guerrireo[0];

            Frz_res.Text = Frz.ToString();
            Dex_res.Text = Dex.ToString();
            Con_res.Text = Con.ToString();
            Int_res.Text = Int.ToString();
            Wis_res.Text = Wis.ToString();
            Cha_res.Text = Cha.ToString();

            Frz_Mod = Modifica(Frz);
            Dex_Mod = Modifica(Dex);
            Con_Mod = Modifica(Con);
            Int_Mod = Modifica(Int);
            Wis_Mod = Modifica(Wis);
            Cha_Mod = Modifica(Cha);

            Frz_mod.Text = Frz_Mod.ToString();
            Dex_mod.Text = Dex_Mod.ToString();
            Con_mod.Text = Con_Mod.ToString();
            Int_mod.Text = Int_Mod.ToString();
            Wis_mod.Text = Wis_Mod.ToString();
            Cha_mod.Text = Cha_Mod.ToString();
        } //GUERRIERO

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int[] ladro = new int[6];

            ladro[0] = Calcolo();
            ladro[1] = Calcolo();
            ladro[2] = Calcolo();
            ladro[3] = Calcolo();
            ladro[4] = Calcolo();
            ladro[5] = Calcolo();

            ladro = Riordinamento(ladro);

            Dex = ladro[5];
            Cha = ladro[4];
            Wis = ladro[3];
            Frz = ladro[2];
            Int = ladro[1];
            Con = ladro[0];

            Frz_res.Text = Frz.ToString();
            Dex_res.Text = Dex.ToString();
            Con_res.Text = Con.ToString();
            Int_res.Text = Int.ToString();
            Wis_res.Text = Wis.ToString();
            Cha_res.Text = Cha.ToString();

            Frz_Mod = Modifica(Frz);
            Dex_Mod = Modifica(Dex);
            Con_Mod = Modifica(Con);
            Int_Mod = Modifica(Int);
            Wis_Mod = Modifica(Wis);
            Cha_Mod = Modifica(Cha);

            Frz_mod.Text = Frz_Mod.ToString();
            Dex_mod.Text = Dex_Mod.ToString();
            Con_mod.Text = Con_Mod.ToString();
            Int_mod.Text = Int_Mod.ToString();
            Wis_mod.Text = Wis_Mod.ToString();
            Cha_mod.Text = Cha_Mod.ToString();
        } //LADRO

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            int[] studioso = new int[6];

            //studioso[0] = Calcolo();
            //studioso[1] = Calcolo();
            //studioso[2] = Calcolo();
            //studioso[3] = Calcolo();
            //studioso[4] = Calcolo();
            //studioso[5] = Calcolo();

            for (int i = 0; i < 6; i++)
            {
                studioso[i] = Calcolo();
            }

            studioso = Riordinamento(studioso);

            Int = studioso[5];
            Wis = studioso[4];
            Dex = studioso[3];
            Frz = studioso[2];
            Cha = studioso[1];
            Con = studioso[0];

            Frz_res.Text = Frz.ToString();
            Dex_res.Text = Dex.ToString();
            Con_res.Text = Con.ToString();
            Int_res.Text = Int.ToString();
            Wis_res.Text = Wis.ToString();
            Cha_res.Text = Cha.ToString();

            Frz_Mod = Modifica(Frz);
            Dex_Mod = Modifica(Dex);
            Con_Mod = Modifica(Con);
            Int_Mod = Modifica(Int);
            Wis_Mod = Modifica(Wis);
            Cha_Mod = Modifica(Cha);

            Frz_mod.Text = Frz_Mod.ToString();
            Dex_mod.Text = Dex_Mod.ToString();
            Con_mod.Text = Con_Mod.ToString();
            Int_mod.Text = Int_Mod.ToString();
            Wis_mod.Text = Wis_Mod.ToString();
            Cha_mod.Text = Cha_Mod.ToString();
        } //STUDIOSO

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 5);
            Stamp.Text = dado.ToString();
        } //D4

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 7);
            Stamp.Text = dado.ToString();
        } //D6

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 9);
            Stamp.Text = dado.ToString();
        } //D8

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 11);
            Stamp.Text = dado.ToString();
        } //D10

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 13);
            Stamp.Text = dado.ToString();
        } //D12

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 21);
            Stamp.Text = dado.ToString();
        } //D20

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            int dado = 0;
            dado = rnd.Next(1, 101);
            Stamp.Text = dado.ToString();
        } //D100

        private int Calcolo()
        {
            int somma = 0;
            somma = rnd.Next(8, 19);
            return somma;
        }

        private int[] Riordinamento(int[] Array)
        {

            int temp = 0;

            for (int i = 0; i < 6 - 1; i++)
            {
                for (int j = i+1; j < 6; j++)
                {
                    if (Array[i] > Array[j])
                    {
                        temp = Array[i];
                        Array[i] = Array[j];
                        Array[j] = temp;
                    }
                }
            }
            return Array;
        }

        private int Modifica(int Caratteristica)
        {

            int Modificatore = 0;

            switch (Caratteristica)
            {
                case 7:
                    Modificatore = -2;
                    break;
                case 8:
                    Modificatore = -1;
                    break;
                case 9:
                    Modificatore = -1;
                    break;
                case 10:
                    Modificatore = +0;
                    break;
                case 11:
                    Modificatore = +0;
                    break;
                case 12:
                    Modificatore = +1;
                    break;
                case 13:
                    Modificatore = +1;
                    break;
                case 14:
                    Modificatore = +2;
                    break;
                case 15:
                    Modificatore = +2;
                    break;
                case 16:
                    Modificatore = +3;
                    break;
                case 17:
                    Modificatore = +3;
                    break;
                case 18:
                    Modificatore = +4;
                    break;
                default:
                    break;
            }

            return Modificatore;

        }

    }
}